// Placeholder Firebase SDK loader.
// IMPORTANT: replace this file with the official Firebase SDK scripts or use CDN in production.
// For easy setup, the wrapper below expects you to add your Firebase config in firebase-config.js
console.warn('firebase-app.js: This file is a lightweight shim. Replace with official Firebase SDK (recommended).');