// Lightweight Firebase auth frontend wrapper using modular SDK pattern.
// This file expects firebase-config.js to be present and the real Firebase SDK to be loaded in production.
// For quick local testing WITHOUT Firebase, this wrapper falls back to a localStorage-based mock.
//
// Usage (exposed in window):
//  - auth_createUserWithEmail(email,password,{displayName})
//  - auth_signInWithEmail(email,password)
//  - auth_signOut()
//  - auth_getCurrentUser()
//  - auth_onAuthStateChanged(callback)
//
// NOTE: For production, replace firebase-app.js with official SDK and import firebaseConfig then initialize app/auth.
(async function(){
  // Simple mock implementation when Firebase SDK isn't loaded.
  function _getStorageUser() {
    try { return JSON.parse(localStorage.getItem('fm_user')); } catch(e){ return null; }
  }
  function _setStorageUser(u) { localStorage.setItem('fm_user', JSON.stringify(u)); }
  function _clearStorageUser(){ localStorage.removeItem('fm_user'); }

  const listeners = [];
  function notify(u){ listeners.forEach(cb=>{ try{ cb(u); }catch(e){} }); }

  // Exposed functions
  window.auth_createUserWithEmail = async function(email, password, profile){
    // Very small validation
    if (!email || !password) throw new Error('Email and password are required');
    const user = {uid: 'local-'+Date.now(), email: email, displayName: profile && profile.displayName ? profile.displayName : ''};
    // Store credentials (INSECURE: only for local testing)
    localStorage.setItem('fm_credentials', JSON.stringify({email,password}));
    _setStorageUser(user);
    notify(user);
    return user;
  };

  window.auth_signInWithEmail = async function(email, password){
    const creds = JSON.parse(localStorage.getItem('fm_credentials')||'null');
    if (!creds || creds.email !== email || creds.password !== password) throw new Error('Invalid email or password (local mock)');
    const user = {uid:'local-'+Date.now(), email: email, displayName: ''};
    _setStorageUser(user);
    notify(user);
    return user;
  };

  window.auth_signOut = async function(){
    _clearStorageUser();
    notify(null);
  };

  window.auth_getCurrentUser = async function(){
    return _getStorageUser();
  };

  window.auth_onAuthStateChanged = function(cb){
    listeners.push(cb);
    // return unsubscribe
    return ()=> {
      const idx = listeners.indexOf(cb);
      if (idx>=0) listeners.splice(idx,1);
    };
  };

  // If you want to wire real Firebase, replace this file content by using:
  // import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.1/firebase-app.js';
  // import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, updateProfile } from 'https://www.gstatic.com/firebasejs/9.22.1/firebase-auth.js';
  // and then implement wrappers that call real Firebase auth functions.
})();
