// Minimal Express + MySQL auth example (do NOT expose in production without HTTPS and proper safeguards)
const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASS || '',
  database: process.env.DB_NAME || 'memory_game',
  waitForConnections: true,
  connectionLimit: 10,
});

app.post('/api/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!email || !password) return res.status(400).json({error:'email+password required'});
  const [rows] = await pool.query('SELECT id FROM users WHERE email=?', [email]);
  if (rows.length) return res.status(400).json({error:'Email already registered'});
  const hash = await bcrypt.hash(password, 10);
  await pool.query('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)', [name||'', email, hash]);
  res.json({ok:true});
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const [rows] = await pool.query('SELECT id,name,email,password_hash FROM users WHERE email=?', [email]);
  if (!rows.length) return res.status(400).json({error:'Invalid credentials'});
  const u = rows[0];
  const ok = await bcrypt.compare(password, u.password_hash);
  if (!ok) return res.status(400).json({error:'Invalid credentials'});
  // In production return JWT or session cookie. Here we just return user info.
  res.json({id:u.id,name:u.name,email:u.email});
});

const port = process.env.PORT || 3001;
app.listen(port, ()=> console.log('Auth server listening on',port));
