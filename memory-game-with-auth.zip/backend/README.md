Node + MySQL backend (boilerplate)

This directory contains a minimal Express server that demonstrates how you could implement
email/password authentication with MySQL. It is NOT wired to the frontend in this zip by default.

Steps to run (if you want to use backend):
1. Install Node and MySQL.
2. Create a database, run the SQL in schema.sql to create 'users' table.
3. Update .env with your DB credentials.
4. In backend/, run:
   npm install
   node server.js

This server exposes endpoints:
 - POST /api/register  {name,email,password}
 - POST /api/login     {email,password}

Passwords in this demo are hashed using bcrypt.

Use this backend only if you prefer server-side auth with MySQL.
