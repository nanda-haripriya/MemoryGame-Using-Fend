Memory Game with Authentication (Ready-to-run)

This package contains:
 - A small Memory Game frontend (index.html)
 - Login and Signup pages using a lightweight auth wrapper (firebase-auth-frontend.js)
 - Profile page
 - Styles under styles/
 - Placeholder firebase-config.js for adding real Firebase config
 - Optional backend folder with Node + MySQL boilerplate (see backend/README.md)

IMPORTANT - Quick start (client-only, local):

1) Unzip the package and open the folder in VS Code.
2) Optional: install Live Server extension in VS Code.
3) Open index.html or right-click -> Open with Live Server.
4) Use Signup to create a test account (stored in localStorage for quick testing).
5) To use real Firebase authentication:
   - Replace firebase-app.js with official Firebase SDK script tags or import.
   - Fill firebase-config.js with your Firebase project's config (from Firebase Console).
   - Update firebase-auth-frontend.js to initialize Firebase and replace mock functions with real SDK calls (comments in file show how).

Backend (optional):
 - backend/ contains an Express + MySQL starter. It's optional and not required for this demo.
 - See backend/README.md for instructions.

If you want, I can:
 - Wire the project to your Firebase project (I will need your firebaseConfig values).
 - Set up the Node+MySQL backend and create API endpoints for registration/login (then remove client-side mock).
